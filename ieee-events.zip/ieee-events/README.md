# IEEE Student Branch - Events Site

HTML + CSS + JavaScript front-end with a Node.js (Express) backend. Data is stored in JSON files, so no database setup is needed.

## Run on localhost
1. Install Node.js 18+ from https://nodejs.org
2. In this folder:
   ```
   npm install
   npm start
   ```
3. Open http://localhost:3000  (works on your phone too: use http://<your-PC-IP>:3000 on the same Wi-Fi)

Organiser panel: http://localhost:3000/admin.html  (default key `ieee-admin`)
Change it:  `ADMIN_KEY=mysecret npm start`  (Windows PowerShell: `$env:ADMIN_KEY="mysecret"; npm start`)

## Register number format
`YEAR + EVENTCODE + 5 digits`, e.g. `2026AIHCK48213`
- YEAR = year of the event, EVENTCODE = 5-letter code of the event, digits = random, checked for uniqueness.

## Edit events
- Easiest: Organiser panel -> Add event.
- Or edit `data/events.json` (restart not needed).
- Registrations are saved in `data/registrations.json`. Export CSV from the organiser panel.

## API
GET  /api/events           list events with seats left
POST /api/register         { eventId, name, email, phone, college, department, year, ieeeNo? }
GET  /api/registration/:id look up a register number
Admin (header x-admin-key): GET /api/admin/registrations[.csv], POST/DELETE /api/admin/events
