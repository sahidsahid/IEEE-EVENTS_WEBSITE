/* IEEE Events - Express backend with JSON file storage */
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'ieee-admin';
const DATA_DIR = path.join(__dirname, 'data');
const EVENTS_FILE = path.join(DATA_DIR, 'events.json');
const REG_FILE = path.join(DATA_DIR, 'registrations.json');

const app = express();
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ---------- storage helpers ---------- */
function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return fallback; }
}
function writeJSON(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file); // atomic replace
}
if (!fs.existsSync(REG_FILE)) writeJSON(REG_FILE, []);

const getEvents = () => readJSON(EVENTS_FILE, []);
const getRegs = () => readJSON(REG_FILE, []);

/* ---------- unique register number: YEAR + EVENTCODE + 5 digits ---------- */
function generateRegId(event, regs) {
  const year = String(event.date).slice(0, 4);
  const taken = new Set(regs.map(r => r.regId));
  for (let i = 0; i < 1000; i++) {
    const n = crypto.randomInt(10000, 100000);
    const id = `${year}${event.code}${n}`;
    if (!taken.has(id)) return id;
  }
  throw new Error('Could not generate unique id');
}

function withSeats(event, regs) {
  const registered = regs.filter(r => r.eventId === event.id).length;
  return { ...event, registered, seatsLeft: Math.max(0, event.capacity - registered) };
}

/* ---------- tiny in-memory rate limit for registration ---------- */
const hits = new Map();
function rateLimit(req, res, next) {
  const now = Date.now();
  const arr = (hits.get(req.ip) || []).filter(t => now - t < 60000);
  if (arr.length >= 8) return res.status(429).json({ error: 'Too many attempts. Try again in a minute.' });
  arr.push(now); hits.set(req.ip, arr); next();
}

/* ---------- public API ---------- */
app.get('/api/events', (req, res) => {
  const regs = getRegs();
  const list = getEvents()
    .map(e => withSeats(e, regs))
    .sort((a, b) => a.date.localeCompare(b.date));
  res.json(list);
});

app.get('/api/events/:id', (req, res) => {
  const e = getEvents().find(x => x.id === req.params.id);
  if (!e) return res.status(404).json({ error: 'Event not found' });
  res.json(withSeats(e, getRegs()));
});

const clean = (v, max = 120) => String(v ?? '').replace(/[<>]/g, '').trim().slice(0, max);

app.post('/api/register', rateLimit, (req, res) => {
  const b = req.body || {};
  const data = {
    eventId: clean(b.eventId),
    name: clean(b.name, 80),
    email: clean(b.email, 120).toLowerCase(),
    phone: clean(b.phone, 15).replace(/\D/g, ''),
    college: clean(b.college, 120),
    department: clean(b.department, 60),
    year: clean(b.year, 20),
    ieeeNo: clean(b.ieeeNo, 20)
  };

  const errors = {};
  if (data.name.length < 2) errors.name = 'Enter your full name';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) errors.email = 'Enter a valid email';
  if (!/^\d{10}$/.test(data.phone)) errors.phone = 'Enter a 10-digit mobile number';
  if (data.college.length < 2) errors.college = 'Enter your college';
  if (!data.department) errors.department = 'Select your department';
  if (!data.year) errors.year = 'Select your year';
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Please fix the highlighted fields', errors });

  const event = getEvents().find(e => e.id === data.eventId);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  const regs = getRegs();
  const count = regs.filter(r => r.eventId === event.id).length;
  if (count >= event.capacity) return res.status(409).json({ error: 'Sorry, this event is full.' });
  if (regs.some(r => r.eventId === event.id && r.email === data.email))
    return res.status(409).json({ error: 'This email is already registered for this event.' });

  const reg = { regId: generateRegId(event, regs), ...data, registeredAt: new Date().toISOString() };
  regs.push(reg);
  writeJSON(REG_FILE, regs);

  res.status(201).json({
    regId: reg.regId,
    name: reg.name,
    event: { id: event.id, name: event.name, date: event.date, time: event.time, venue: event.venue, hall: event.hall }
  });
});

app.get('/api/registration/:regId', (req, res) => {
  const id = clean(req.params.regId, 30).toUpperCase();
  const reg = getRegs().find(r => r.regId === id);
  if (!reg) return res.status(404).json({ error: 'No registration found with that number.' });
  const event = getEvents().find(e => e.id === reg.eventId);
  res.json({
    regId: reg.regId, name: reg.name, registeredAt: reg.registeredAt,
    event: event && { name: event.name, date: event.date, time: event.time, venue: event.venue, hall: event.hall }
  });
});

/* ---------- admin API ---------- */
function admin(req, res, next) {
  const key = req.get('x-admin-key') || '';
  const a = Buffer.from(key), b = Buffer.from(ADMIN_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b))
    return res.status(401).json({ error: 'Invalid admin key' });
  next();
}

app.get('/api/admin/registrations', admin, (req, res) => {
  const events = getEvents();
  const regs = getRegs().map(r => ({ ...r, eventName: (events.find(e => e.id === r.eventId) || {}).name || r.eventId }));
  res.json(req.query.event ? regs.filter(r => r.eventId === req.query.event) : regs);
});

app.get('/api/admin/registrations.csv', admin, (req, res) => {
  const events = getEvents();
  const cols = ['regId', 'eventName', 'name', 'email', 'phone', 'college', 'department', 'year', 'ieeeNo', 'registeredAt'];
  const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = getRegs().map(r => {
    const x = { ...r, eventName: (events.find(e => e.id === r.eventId) || {}).name || r.eventId };
    return cols.map(c => esc(x[c])).join(',');
  });
  res.set({ 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename="registrations.csv"' });
  res.send([cols.join(','), ...rows].join('\n'));
});

app.post('/api/admin/events', admin, (req, res) => {
  const b = req.body || {};
  const e = {
    id: 'evt-' + crypto.randomBytes(4).toString('hex'),
    code: clean(b.code, 5).toUpperCase().replace(/[^A-Z0-9]/g, ''),
    name: clean(b.name, 80), category: clean(b.category, 30) || 'Event',
    date: clean(b.date, 10), time: clean(b.time, 20), endTime: clean(b.endTime, 30),
    venue: clean(b.venue, 80), hall: clean(b.hall, 80),
    capacity: Math.max(1, parseInt(b.capacity, 10) || 50),
    fee: Math.max(0, parseInt(b.fee, 10) || 0),
    description: clean(b.description, 300)
  };
  if (e.code.length !== 5 || !e.name || !/^\d{4}-\d{2}-\d{2}$/.test(e.date) || !e.venue)
    return res.status(400).json({ error: 'Need: 5-char code, name, date (YYYY-MM-DD), venue' });
  const events = getEvents();
  events.push(e); writeJSON(EVENTS_FILE, events);
  res.status(201).json(e);
});

app.delete('/api/admin/events/:id', admin, (req, res) => {
  const events = getEvents();
  const next = events.filter(e => e.id !== req.params.id);
  if (next.length === events.length) return res.status(404).json({ error: 'Event not found' });
  writeJSON(EVENTS_FILE, next);
  res.json({ ok: true });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, () => {
  console.log(`\n  IEEE Events running ->  http://localhost:${PORT}`);
  console.log(`  Admin panel         ->  http://localhost:${PORT}/admin.html  (key: ${ADMIN_KEY})\n`);
});
