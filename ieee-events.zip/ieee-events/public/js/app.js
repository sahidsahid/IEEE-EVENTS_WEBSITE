/* IEEE Events front-end */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const parts = iso => { const [y, m, d] = iso.split('-').map(Number); return { y, m: MONTHS[m - 1], d }; };
  const longDate = iso => { const p = parts(iso); return `${p.d} ${p.m} ${p.y}`; };

  let events = [];
  let activeCat = 'All';
  let current = null;       // event being registered
  let lastFocus = null;
  let lastTicket = null;

  /* ---------- toast ---------- */
  let tt;
  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ---------- nav ---------- */
  const nav = $('#nav'), burger = $('#burger'), links = $('#navLinks');
  const onScroll = () => nav.classList.toggle('scrolled', scrollY > 30);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  burger.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  links.addEventListener('click', e => {
    if (e.target.closest('a')) { links.classList.remove('open'); burger.setAttribute('aria-expanded', false); }
  });
  // active link on scroll
  const secs = $$('main section[id]').map(s => ({ s, a: $(`.nav-links a[href="#${s.id}"]`) })).filter(x => x.a);
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { $$('.nav-links a').forEach(a => a.classList.remove('active')); secs.find(x => x.s === e.target)?.a.classList.add('active'); }
  }), { rootMargin: '-45% 0px -50% 0px' });
  secs.forEach(x => io.observe(x.s));
  $('#yr').textContent = new Date().getFullYear();

  /* ---------- events ---------- */
  async function api(url, opts) {
    const r = await fetch(url, opts);
    const data = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(data.error || 'Something went wrong'); e.data = data; e.status = r.status; throw e; }
    return data;
  }

  async function loadEvents() {
    try {
      events = await api('/api/events');
      renderFilters(); renderEvents(); renderStats();
    } catch (e) {
      $('#eventsGrid').innerHTML = `<div class="load-error">Could not load events. Make sure the server is running (<code>npm start</code>) and refresh.</div>`;
    }
  }

  function renderStats() {
    const seats = events.reduce((n, e) => n + e.seatsLeft, 0);
    $('#heroStats').innerHTML = `
      <span class="pill solid-white">${events.length} upcoming events</span>
      <span class="pill">${seats} seats open</span>`;
  }

  function renderFilters() {
    const cats = ['All', ...new Set(events.map(e => e.category))];
    $('#filters').innerHTML = cats.map(c => `<button class="pill filter" type="button" aria-pressed="${c === activeCat}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
  }
  $('#filters').addEventListener('click', e => {
    const b = e.target.closest('.filter'); if (!b) return;
    activeCat = b.dataset.cat; renderFilters(); renderEvents();
  });

  const pin = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/></svg>';

  function renderEvents() {
    const list = events.filter(e => activeCat === 'All' || e.category === activeCat);
    if (!list.length) { $('#eventsGrid').innerHTML = '<div class="empty">No events in this category yet.</div>'; return; }
    $('#eventsGrid').innerHTML = list.map(e => {
      const p = parts(e.date), full = e.seatsLeft === 0;
      const pct = Math.round((e.registered / e.capacity) * 100);
      return `
      <article class="ev-card" data-id="${esc(e.id)}">
        <div class="ev-top">
          <div class="ev-date"><b>${p.d}</b><span>${p.m} ${p.y}</span></div>
          <span class="pill">${esc(e.category)}</span>
        </div>
        <h3 class="ev-name">${esc(e.name)}</h3>
        <p class="ev-desc">${esc(e.description)}</p>
        <div class="venue">
          ${pin}
          <span class="v-label">Venue</span>
          <span class="v-name">${esc(e.venue)}${e.hall ? `, ${esc(e.hall)}` : ''}</span>
          <span class="v-time">${esc(e.time)}${e.endTime ? ` to ${esc(e.endTime)}` : ''}</span>
        </div>
        <div class="seats">
          <span>${full ? 'Fully booked' : `${e.seatsLeft} of ${e.capacity} seats left`}</span>
          <div class="seats-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="Seats filled"><i style="width:${pct}%"></i></div>
        </div>
        <div class="ev-foot">
          <span class="fee">${e.fee ? '&#8377;' + e.fee : 'Free'}</span>
          <button class="btn btn-primary reg-btn" type="button" ${full ? 'disabled' : ''}>${full ? 'Sold out' : 'Register now'}</button>
        </div>
      </article>`;
    }).join('');
  }
  $('#eventsGrid').addEventListener('click', e => {
    const btn = e.target.closest('.reg-btn'); if (!btn || btn.disabled) return;
    openModal(events.find(x => x.id === btn.closest('.ev-card').dataset.id), btn);
  });

  /* ---------- modal ---------- */
  const modal = $('#modal'), form = $('#regForm');

  function openModal(ev, opener) {
    current = ev; lastFocus = opener || document.activeElement;
    form.reset(); clearErrors();
    $('#mTitle').textContent = ev.name;
    $('#mSub').textContent = `${longDate(ev.date)} at ${ev.time}, ${ev.venue}${ev.hall ? ', ' + ev.hall : ''}`;
    $('#formView').hidden = false; $('#doneView').hidden = true;
    modal.classList.add('open'); document.body.style.overflow = 'hidden';
    setTimeout(() => $('#f-name').focus(), 50);
  }
  function closeModal() {
    modal.classList.remove('open'); document.body.style.overflow = '';
    if (lastTicket) { loadEvents(); lastTicket = null; }
    lastFocus?.focus?.();
  }
  $('#mClose').addEventListener('click', closeModal);
  modal.addEventListener('mousedown', e => { if (e.target === modal) closeModal(); });
  addEventListener('keydown', e => {
    if (!modal.classList.contains('open')) return;
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Tab') { // keep focus inside the dialog
      const f = $$('button:not([disabled]), input, select', modal).filter(x => x.offsetParent);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  function clearErrors() {
    $$('.field', form).forEach(f => { f.classList.remove('invalid'); $('.err', f).textContent = ''; });
    $('#formMsg').classList.remove('show');
  }
  function showErrors(errors = {}) {
    Object.entries(errors).forEach(([k, msg]) => {
      const input = form.elements[k]; if (!input) return;
      const f = input.closest('.field'); f.classList.add('invalid'); $('.err', f).textContent = msg;
    });
    const first = form.querySelector('.invalid input, .invalid select'); first?.focus();
  }

  // client-side validation mirrors the server
  function validate(d) {
    const e = {};
    if (d.name.trim().length < 2) e.name = 'Enter your full name';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email.trim())) e.email = 'Enter a valid email';
    if (!/^\d{10}$/.test(d.phone.replace(/\D/g, ''))) e.phone = 'Enter a 10-digit mobile number';
    if (d.college.trim().length < 2) e.college = 'Enter your college';
    if (!d.department) e.department = 'Select your department';
    if (!d.year) e.year = 'Select your year';
    return e;
  }

  form.addEventListener('submit', async ev => {
    ev.preventDefault(); clearErrors();
    const d = Object.fromEntries(new FormData(form));
    const errs = validate(d);
    if (Object.keys(errs).length) { showErrors(errs); return; }
    const btn = $('#submitBtn'); btn.disabled = true; btn.textContent = 'Registering...';
    try {
      const res = await api('/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...d, eventId: current.id }) });
      showTicket(res);
    } catch (err) {
      if (err.data?.errors) showErrors(err.data.errors);
      const m = $('#formMsg'); m.textContent = err.message; m.classList.add('show');
    } finally { btn.disabled = false; btn.textContent = 'Confirm registration'; }
  });

  function showTicket(res) {
    lastTicket = res;
    $('#formView').hidden = true; $('#doneView').hidden = false;
    $('#tId').textContent = res.regId;
    $('#tMeta').innerHTML = `
      <div class="full"><small>Event</small><strong>${esc(res.event.name)}</strong></div>
      <div><small>Name</small>${esc(res.name)}</div>
      <div><small>Date</small>${esc(longDate(res.event.date))}, ${esc(res.event.time)}</div>
      <div class="full"><small>Venue</small>${esc(res.event.venue)}${res.event.hall ? ', ' + esc(res.event.hall) : ''}</div>`;
    $('#copyBtn').focus();
  }

  $('#copyBtn').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(lastTicket.regId); toast('Register number copied'); }
    catch { toast('Select and copy the number manually'); }
  });

  /* ---------- ticket PNG (canvas) ---------- */
  $('#dlBtn').addEventListener('click', () => {
    const t = lastTicket; if (!t) return;
    const W = 900, H = 520, c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d'), font = 'Instrument Sans, system-ui, sans-serif';
    const bg = g.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#4a2ba8'); bg.addColorStop(1, '#0f042d');
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    g.fillStyle = '#efefef'; g.beginPath(); g.roundRect(30, 110, W - 60, H - 140, 24); g.fill();
    g.fillStyle = '#fff'; g.font = `700 30px ${font}`; g.fillText('IEEE Student Branch', 40, 62);
    g.font = `500 20px ${font}`; g.fillStyle = 'rgba(255,255,255,.75)'; g.fillText('Entry pass', 40, 90);
    g.fillStyle = '#0f042d'; g.font = `500 18px ${font}`; g.fillText('Register number', 60, 160);
    g.font = `700 58px ${font}`; g.fillText(t.regId, 60, 225);
    g.strokeStyle = 'rgba(15,4,45,.35)'; g.setLineDash([8, 8]); g.beginPath(); g.moveTo(60, 255); g.lineTo(W - 60, 255); g.stroke(); g.setLineDash([]);
    const row = (label, val, x, y) => { g.fillStyle = 'rgba(15,4,45,.6)'; g.font = `500 15px ${font}`; g.fillText(label, x, y); g.fillStyle = '#0f042d'; g.font = `600 22px ${font}`; g.fillText(val.slice(0, 38), x, y + 28); };
    row('Event', t.event.name, 60, 295);
    row('Name', t.name, 60, 365);
    row('Date', `${longDate(t.event.date)}, ${t.event.time}`, 480, 365);
    row('Venue', `${t.event.venue}${t.event.hall ? ', ' + t.event.hall : ''}`, 60, 435);
    const a = document.createElement('a'); a.download = `${t.regId}.png`; a.href = c.toDataURL('image/png'); a.click();
  });

  /* ---------- lookup ---------- */
  $('#lookupForm').addEventListener('submit', async e => {
    e.preventDefault();
    const id = $('#lookupInput').value.trim().toUpperCase(), out = $('#lookupResult');
    if (!id) { out.innerHTML = ''; return; }
    out.innerHTML = '<p>Searching...</p>';
    try {
      const r = await api('/api/registration/' + encodeURIComponent(id));
      out.innerHTML = `
        <div class="card-solid">
          <h3>${esc(r.regId)}</h3><hr>
          <p><strong>${esc(r.name)}</strong> is registered for <strong>${esc(r.event?.name || 'an event')}</strong>.</p>
          ${r.event ? `<p style="margin-top:8px">${esc(longDate(r.event.date))}, ${esc(r.event.time)} at ${esc(r.event.venue)}${r.event.hall ? ', ' + esc(r.event.hall) : ''}</p>` : ''}
        </div>`;
    } catch (err) {
      out.innerHTML = `<div class="card-outline"><p>${esc(err.message)}</p></div>`;
    }
  });

  loadEvents();
})();
